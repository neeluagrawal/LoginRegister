package example.com.userinfodatabase.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import example.com.userinfodatabase.model.UserLogin;
import example.com.userinfodatabase.model.UserProfile;

public class DbHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "UserLogin";

    private static final String TABLE_LOGIN = "UserLogin";
    private static final String TABLE_PROFILE = "UserProfile";
    private static String KEY_ID = "userId";
    private static String KEY_PROFILE_ID = "profileId";
    private static String KEY_FIRST_NAME = "firstName";
    private static String KEY_LAST_NAME = "lastName";
    private static String KEY_EMAIL = "email";
    private static String KEY_PASSWORD = "password";
    private static String KEY_ADDRESS = "address";
    private static String KEY_PHONE = "phone";
    private static String KEY_DESIGNATION = "designation";
    private static String KEY_DEPARTMENT = "department";
    private static String KEY_INCOME = "income";
    //    autoincrement
    private static final String CREATE_TABLE_LOGIN = "CREATE TABLE IF NOT EXISTS "
            + TABLE_LOGIN + "(" + KEY_ID + " INTEGER PRIMARY KEY NOT NULL," + KEY_FIRST_NAME
            + " TEXT," + KEY_LAST_NAME + " TEXT," + KEY_EMAIL + " TEXT," + KEY_PASSWORD + " TEXT" + ")";

    private static final String CREATE_TABLE_PROFILE = "CREATE TABLE IF NOT EXISTS " + TABLE_PROFILE + " (" + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + KEY_PROFILE_ID + " INTEGER," + KEY_ADDRESS + " TEXT," + KEY_PHONE + " TEXT," + KEY_DESIGNATION + " TEXT," + KEY_DEPARTMENT +
            " TEXT," + KEY_INCOME + " TEXT," + " FOREIGN KEY(" + KEY_PROFILE_ID + ") REFERENCES " + TABLE_LOGIN + "(" + KEY_ID + "))";

    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(CREATE_TABLE_LOGIN);
        db.execSQL(CREATE_TABLE_PROFILE);
        Log.e("--table created", "table CREATE_TABLE_LOGIN");
        Log.e("--table created", "table CREATE_TABLE_PROFILE");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOGIN);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PROFILE);

        onCreate(db);
        Log.e("--table upgrade", "table TABLE_PROFILE");
        Log.e("--table upgrade", "table TABLE_PROFILE");

    }

    public void addUserData(UserLogin userLogin) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues valuesLogin = new ContentValues();
        valuesLogin.put(KEY_FIRST_NAME, userLogin.getFirstName());
        valuesLogin.put(KEY_LAST_NAME, userLogin.getLastName());
        valuesLogin.put(KEY_EMAIL, userLogin.getEmail());
        valuesLogin.put(KEY_PASSWORD, userLogin.getPassword());
        db.insert(TABLE_LOGIN, null, valuesLogin);
        Log.e("--data inserted", "inserted user data");
        db.close();

    }

    public void addUserProfile(UserProfile userProfile, String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues valuesProfile = new ContentValues();
        valuesProfile.put(KEY_PROFILE_ID, id);
        valuesProfile.put(KEY_ADDRESS, userProfile.getAddress());
        valuesProfile.put(KEY_PHONE, userProfile.getPhone());
        valuesProfile.put(KEY_DESIGNATION, userProfile.getDesignation());
        valuesProfile.put(KEY_DEPARTMENT, userProfile.getDepartment());
        valuesProfile.put(KEY_INCOME, userProfile.getIncome());
        db.insert(TABLE_PROFILE, null, valuesProfile);
        Log.e("--data inserted", "inserted user data profile");
        db.close();
    }

    public void deleteUserData(UserLogin userLogin) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_LOGIN, KEY_ID + " = ?", new String[]{String.valueOf(userLogin.getId())});
        Log.e("--table data deleted", "table data deleted");
        db.close();
    }

    public String getSingleUserDataMatch(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_LOGIN, new String[]{KEY_ID, KEY_FIRST_NAME, KEY_PASSWORD}, KEY_FIRST_NAME + "=?",
                new String[]{name}, null, null, null);
        if (cursor.getCount() < 1) // UserName Not Exist
            return "NOT EXIST";
        cursor.moveToFirst();
        String password = cursor.getString(cursor.getColumnIndex(KEY_PASSWORD));
        return password;
    }

    public boolean isDataExistInUserProfile(String id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_PROFILE, new String[]{KEY_ID, KEY_ADDRESS, KEY_PHONE, KEY_DESIGNATION
                        , KEY_DEPARTMENT, KEY_INCOME}, KEY_PROFILE_ID + "=?",
                new String[]{id}, null, null, null);
        if (cursor.getCount() < 1) // UserName Not Exist
            return false;
        cursor.moveToFirst();

        return true;
    }

    public int getUserDataCount() {
        String countQuerry = "SELECT * FROM " + TABLE_LOGIN;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuerry, null);
        return cursor.getCount();
    }

    public int getUserProfileCount() {
        String countQuerry = "SELECT * FROM " + TABLE_PROFILE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuerry, null);
        return cursor.getCount();
    }

    public int updateUserData(int id, String firstName, String lastName, String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_FIRST_NAME, firstName);
        values.put(KEY_LAST_NAME, lastName);
        values.put(KEY_EMAIL, email);
        return db.update(TABLE_LOGIN, values, KEY_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public int updateUserProfileData(String id, String address, String phone, String designation, String department, String income) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_ADDRESS, address);
        values.put(KEY_PHONE, phone);
        values.put(KEY_DESIGNATION, designation);
        values.put(KEY_DEPARTMENT, department);
        values.put(KEY_INCOME, income);
        return db.update(TABLE_PROFILE, values, KEY_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public List<UserLogin> getAllUserData() {
        List<UserLogin> userLoginList = new ArrayList<>();
        String selectQuerry = "SELECT * FROM " + TABLE_LOGIN;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuerry, null);
        if (cursor.moveToFirst()) {
            do {
                UserLogin userLogin = new UserLogin();
                userLogin.setId(cursor.getInt(0));
                userLogin.setFirstName(cursor.getString(1));
                userLogin.setLastName(cursor.getString(2));
                userLogin.setEmail(cursor.getString(3));
                userLogin.setPassword(cursor.getString(4));
                userLoginList.add(userLogin);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return userLoginList;
    }

    public List<UserProfile> getAllUserProfile() {
        List<UserProfile> userProfileList = new ArrayList<>();
        String selectQuerry = "SELECT * FROM " + TABLE_PROFILE;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuerry, null);
        if (cursor.moveToFirst()) {
            do {
                UserProfile userProfile = new UserProfile();
                userProfile.setProfileId(cursor.getInt(0));
                userProfile.setAddress(cursor.getString(1));
                userProfile.setPhone(cursor.getString(2));
                userProfile.setDesignation(cursor.getString(3));
                userProfile.setDepartment(cursor.getString(4));
                userProfile.setIncome(cursor.getString(4));
                userProfileList.add(userProfile);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return userProfileList;
    }

    public UserLogin getSingleDataSuccessLogin(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(TABLE_LOGIN, new String[]{KEY_ID, KEY_FIRST_NAME, KEY_LAST_NAME, KEY_EMAIL, KEY_PASSWORD},
                KEY_FIRST_NAME + "=?", new String[]{String.valueOf(name)}, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();

        UserLogin userLogin = new UserLogin();
        userLogin.setId(cursor.getInt(0));
        userLogin.setFirstName(cursor.getString(1));
        userLogin.setLastName(cursor.getString(2));
        userLogin.setEmail(cursor.getString(3));
        userLogin.setPassword(cursor.getString(4));
        cursor.close();
        db.close();
        return userLogin;
    }

    public String getSingleUserProfileData(String id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_PROFILE, new String[]{KEY_ID, KEY_ADDRESS, KEY_PHONE, KEY_DESIGNATION
                , KEY_DEPARTMENT, KEY_INCOME}, KEY_PROFILE_ID + "=?", new String[]{String.valueOf(id)}, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();

        UserProfile userProfile = new UserProfile();
        userProfile.setProfileId(cursor.getInt(0));
        userProfile.setAddress(cursor.getString(1));
        userProfile.setPhone(cursor.getString(2));
        userProfile.setIdFromLastTable(id);
        userProfile.setDesignation(cursor.getString(3));
        userProfile.setDepartment(cursor.getString(4));
        userProfile.setIncome(cursor.getString(5));
        String address=userProfile.getAddress();
        cursor.close();
        db.close();
        return address;

    }

//    public UserProfile getSingleUserProfileData(String id) {
//        SQLiteDatabase db = this.getReadableDatabase();
//
//        Cursor cursor = db.query(TABLE_PROFILE, new String[]{KEY_ID, KEY_ADDRESS, KEY_PHONE, KEY_DESIGNATION
//                , KEY_DEPARTMENT, KEY_INCOME}, KEY_PROFILE_ID + "=?", new String[]{String.valueOf(id)}, null, null, null, null);
//        if (cursor != null)
//            cursor.moveToFirst();
//
//        UserProfile userProfile = new UserProfile();
//        userProfile.setProfileId(cursor.getInt(0));
//        userProfile.setAddress(cursor.getString(1));
//        userProfile.setPhone(cursor.getString(2));
//        userProfile.setDesignation(cursor.getString(3));
//        userProfile.setDepartment(cursor.getString(4));
//        userProfile.setIncome(cursor.getString(5));
//        userProfile.getAddress();
//        cursor.close();
//        db.close();
//        return userProfile;
//
//    }

}
