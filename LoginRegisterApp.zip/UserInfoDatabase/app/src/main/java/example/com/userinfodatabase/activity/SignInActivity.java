package example.com.userinfodatabase.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import example.com.userinfodatabase.R;
import example.com.userinfodatabase.database.DbHelper;
import example.com.userinfodatabase.model.UserLogin;
import example.com.userinfodatabase.model.UserProfile;

public class SignInActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private boolean doubleBackToExitPressedOnce = false;

    private EditText inputUserName;
    private EditText inputPassword;
    private TextInputLayout inputLayoutUserName;
    private TextInputLayout inputLayoutPassword;
    private Button buttonLogIn;
    private TextView textViewSignIn;

    private String password;
    private String name;

    DbHelper dbHelper = new DbHelper(this);
    UserLogin userLogin = new UserLogin();
    SharedPreferences sp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitvity_sign_in);

        initialiseViews();
    }

    private void initialiseViews() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        inputLayoutUserName = (TextInputLayout) findViewById(R.id.inputLayoutUserName);
        inputLayoutPassword = (TextInputLayout) findViewById(R.id.inputLayoutPassword);
        inputUserName = (EditText) findViewById(R.id.inputUserName);
        inputPassword = (EditText) findViewById(R.id.inputPassword);
        textViewSignIn = (TextView) findViewById(R.id.textViewSignIn);
        buttonLogIn = (Button) findViewById(R.id.buttonLogin);


        inputUserName.addTextChangedListener(new MyTextWatcher(inputUserName));
        inputPassword.addTextChangedListener(new MyTextWatcher(inputPassword));

        textViewSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentSignUp = new Intent(SignInActivity.this, SignUpActivity.class);
                startActivity(intentSignUp);
            }
        });

        buttonLogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkData();
            }
        });
    }

    private void checkData() {

        if (!validateName()) {
            return;
        }

        if (!validatePassword()) {
            return;
        }
        sp = getSharedPreferences("MyProfileData", Context.MODE_PRIVATE);

        String storedPassword = dbHelper.getSingleUserDataMatch(name);
        if (password.equals(storedPassword)) {
            Toast.makeText(getApplicationContext(), "Login Successful!", Toast.LENGTH_LONG).show();
            try {
                userLogin = dbHelper.getSingleDataSuccessLogin(name);
                int id = userLogin.getId();
                String firstName = userLogin.getFirstName();
                String lastName = userLogin.getLastName();
                String email = userLogin.getEmail();
                String password = userLogin.getPassword();

                Intent intent = new Intent(SignInActivity.this, ProfileActivity.class);
                intent.putExtra("id", id);
                intent.putExtra("firstName", firstName);
                intent.putExtra("lastName", lastName);
                intent.putExtra("email", email);
                intent.putExtra("password", password);
                startActivity(intent);
//                String newId = String.valueOf(id);
//                if (dbHelper.getSingleUserProfileData(newId)!=null) {
//                    String address= dbHelper.getSingleUserProfileData(newId);
//                    Log.e("add",address);
//
////                    UserProfile userProfile = new UserProfile();
////                    String address = userProfile.getAddress();
////                    String phoneNumber = userProfile.getPhone();
////                    String designation = userProfile.getDesignation();
////                    String department = userProfile.getDepartment();
////                    String income = userProfile.getIncome();
////
////
////                    intent.putExtra("address", address);
////                    intent.putExtra("phoneNumber", phoneNumber);
////                    intent.putExtra("designation", designation);
////                    intent.putExtra("department", department);
////                    intent.putExtra("income", income);
//                }



            } catch (Exception e) {
            }
        } else {
            Toast.makeText(getApplicationContext(), "Incorrect password!", Toast.LENGTH_LONG).show();
        }
    }


    private boolean validateName() {
        name = inputUserName.getText().toString().trim();
        if (name.isEmpty()) {
            inputLayoutUserName.setError(getString(R.string.err_msg_user_name));
            requestFocus(inputUserName);
            return false;
        } else {
            inputLayoutUserName.setErrorEnabled(false);
        }

        return true;
    }

    private boolean validatePassword() {
        password = inputPassword.getText().toString().trim();
        if (password.isEmpty()) {
            inputLayoutPassword.setError(getString(R.string.err_msg_password));
            requestFocus(inputPassword);
            return false;
        } else {
            inputLayoutPassword.setErrorEnabled(false);
        }

        return true;
    }

    private void requestFocus(View view) {
        if (view.requestFocus()) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
    }

    private class MyTextWatcher implements TextWatcher {

        private View view;

        private MyTextWatcher(View view) {
            this.view = view;
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void afterTextChanged(Editable editable) {
            switch (view.getId()) {
                case R.id.inputFirstName:
                    validateName();
                    break;
                case R.id.inputPassword:
                    validatePassword();
                    break;
            }
        }
    }


    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce = false;
            }
        }, 2000);
    }
}
