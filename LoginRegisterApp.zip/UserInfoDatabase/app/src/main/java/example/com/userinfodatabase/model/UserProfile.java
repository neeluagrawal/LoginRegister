package example.com.userinfodatabase.model;

public class UserProfile {
    int profileId;
    String idFromLastTable;
    String address;
    String phone;
    String designation;
    String department;
    String income;

    public UserProfile() {
    }

    public UserProfile(int profileId, String idFromLastTable, String address, String phone, String designation, String department, String income) {
        this.profileId = profileId;
        this.idFromLastTable = idFromLastTable;
        this.address = address;
        this.phone = phone;
        this.designation = designation;
        this.department = department;
        this.income = income;
    }

    public UserProfile(String idFromLastTable, String address, String phone, String designation, String department, String income) {
        this.idFromLastTable = idFromLastTable;
        this.address = address;
        this.phone = phone;
        this.designation = designation;
        this.department = department;
        this.income = income;
    }

    public UserProfile(String address, String phone, String designation, String department, String income) {
        this.address = address;
        this.phone = phone;
        this.designation = designation;
        this.department = department;
        this.income = income;
    }

    public int getProfileId() {
        return profileId;
    }

    public void setProfileId(int profileId) {
        this.profileId = profileId;
    }

    public String getIdFromLastTable() {
        return idFromLastTable;
    }

    public void setIdFromLastTable(String idFromLastTable) {
        this.idFromLastTable = idFromLastTable;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getIncome() {
        return income;
    }

    public void setIncome(String income) {
        this.income = income;
    }
}
