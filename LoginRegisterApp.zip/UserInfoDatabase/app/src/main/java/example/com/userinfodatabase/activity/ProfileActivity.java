package example.com.userinfodatabase.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

import example.com.userinfodatabase.R;
import example.com.userinfodatabase.database.DbHelper;
import example.com.userinfodatabase.model.UserLogin;
import example.com.userinfodatabase.model.UserProfile;

public class ProfileActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private EditText inputAddress;
    private EditText inputPhoneNumber;
    private EditText inputDesignation;
    private EditText inputDepartment;
    private EditText inputIncome;
    private EditText inputFirstName;
    private EditText inputLastName;
    private EditText inputEmail;
    private TextInputLayout inputLayoutAddress;
    private TextInputLayout inputLayoutPhoneNumber;
    private TextInputLayout inputLayoutDesignation;
    private TextInputLayout inputLayoutDepartment;
    private TextInputLayout inputLayoutIncome;
    private TextInputLayout inputLayoutFirstName;
    private TextInputLayout inputLayoutLastName;
    private TextInputLayout inputLayoutEmail;

    private Button buttonProfileSave;
    private Button buttonLoginSave;


    private String address;
    private String phoneNumber;
    private String designation;
    private String department;
    private String income;
    private int id;
    private String firstName;
    private String lastName;
    private String email;
    private String password;

    UserProfile userProfile = new UserProfile();
    UserLogin userLogin = new UserLogin();
    DbHelper dbHelper = new DbHelper(this);
    Intent intent;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        initialiseViews();
    }

    private void initialiseViews() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        inputLayoutFirstName = (TextInputLayout) findViewById(R.id.inputLayoutFirstName);
        inputLayoutLastName = (TextInputLayout) findViewById(R.id.inputLayoutLastName);
        inputLayoutEmail = (TextInputLayout) findViewById(R.id.inputLayoutEmail);

        inputLayoutAddress = (TextInputLayout) findViewById(R.id.inputLayoutAddress);
        inputLayoutPhoneNumber = (TextInputLayout) findViewById(R.id.inputLayoutPhoneNumber);
        inputLayoutDesignation = (TextInputLayout) findViewById(R.id.inputLayoutDesignation);
        inputLayoutDepartment = (TextInputLayout) findViewById(R.id.inputLayoutDepartment);
        inputLayoutIncome = (TextInputLayout) findViewById(R.id.inputLayoutIncome);

        inputFirstName = (EditText) findViewById(R.id.inputFirstName);
        inputLastName = (EditText) findViewById(R.id.inputLastName);
        inputEmail = (EditText) findViewById(R.id.inputEmail);

        inputAddress = (EditText) findViewById(R.id.inputAddress);
        inputPhoneNumber = (EditText) findViewById(R.id.inputPhoneNumber);
        inputDesignation = (EditText) findViewById(R.id.inputDesignation);
        inputDepartment = (EditText) findViewById(R.id.inputDepartment);
        inputIncome = (EditText) findViewById(R.id.inputIncome);

        buttonLoginSave = (Button) findViewById(R.id.buttonLoginSave);
        buttonProfileSave = (Button) findViewById(R.id.buttonProfileSave);


        inputFirstName.addTextChangedListener(new MyTextWatcher(inputFirstName));
        inputLastName.addTextChangedListener(new MyTextWatcher(inputLastName));
        inputEmail.addTextChangedListener(new MyTextWatcher(inputEmail));

        inputAddress.addTextChangedListener(new MyTextWatcher(inputAddress));
        inputPhoneNumber.addTextChangedListener(new MyTextWatcher(inputPhoneNumber));
        inputDesignation.addTextChangedListener(new MyTextWatcher(inputDesignation));
        inputDepartment.addTextChangedListener(new MyTextWatcher(inputDepartment));
        inputIncome.addTextChangedListener(new MyTextWatcher(inputIncome));

        intent = getIntent();
        if (null != intent) {
            id = intent.getIntExtra("id", 0);
            firstName = intent.getStringExtra("firstName");
            lastName = intent.getStringExtra("lastName");
            email = intent.getStringExtra("email");
            password = intent.getStringExtra("password");
            inputFirstName.setText(firstName);
            inputLastName.setText(lastName);
            inputEmail.setText(email);


//            String intentAddress = intent.getStringExtra("address");
//            String intentPhoneNumber = intent.getStringExtra("phoneNumber");
//            String intentDesignation = intent.getStringExtra("designation");
//            String intentDepartment = intent.getStringExtra("department");
//            String intentIncome = intent.getStringExtra("income");
//
//            inputAddress.setText(intentAddress);
//            inputPhoneNumber.setText(intentPhoneNumber);
//            inputDesignation.setText(intentDesignation);
//            inputDepartment.setText(intentDepartment);
//            inputIncome.setText(intentIncome);


        }

        buttonLoginSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUpdateDetails();
            }
        });


        buttonProfileSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profileUpdateDetails();

            }
        });

    }

    private void loginUpdateDetails() {


        if (!validateFirstName()) {
            return;
        }

        if (!validateLastName()) {
            return;
        }
        if (!validateEmail()) {
            return;
        }
        String newFirstName = inputFirstName.getText().toString();
        String newLastName = inputLastName.getText().toString();
        String newEmail = inputEmail.getText().toString();
        inputFirstName.setText(newFirstName);
        inputLastName.setText(newLastName);
        inputEmail.setText(newEmail);


        userLogin.setFirstName(newFirstName);
        userLogin.setLastName(newLastName);
        userLogin.setEmail(newEmail);

        dbHelper.updateUserData(id, firstName, lastName, email);
        Toast.makeText(getApplicationContext(), "Data is updated successfully", Toast.LENGTH_SHORT).show();
//        List<UserLogin> contacts = dbHelper.getAllUserData();

//        for (UserLogin cn : contacts) {
//            String log = "Id: " + id + " ,Name: " + newFirstName +" "+newEmail+" "+ newLastName+" "+password;
//            // Writing Contacts to log
//            Log.d("Name: ", log);

//        }
    }


    private void profileUpdateDetails() {

        if (!validateAddress()) {
            return;
        }

        if (!validatePhoneNumber()) {
            return;
        }

        if (!validateDesignation()) {
            return;
        }

        if (!validateDepartment()) {
            return;
        }

        if (!validateIncome()) {
            return;
        }

        if (address != null && phoneNumber != null && designation != null && department != null && income != null) {

            String lastTableId = String.valueOf(id);
            userProfile.setIdFromLastTable(lastTableId);
            userProfile.setAddress(address);
            userProfile.setPhone(phoneNumber);
            userProfile.setDesignation(designation);
            userProfile.setDepartment(department);
            userProfile.setIncome(income);
//            sp = getSharedPreferences("MyProfileData", Context.MODE_PRIVATE);
//            SharedPreferences.Editor editor = sp.edit();
            if (!dbHelper.isDataExistInUserProfile(lastTableId)) {
                dbHelper.addUserProfile(userProfile, lastTableId);

//                editor.putString("address", address);
//                editor.putString("phoneNumber", phoneNumber);
//                editor.putString("designation", designation);
//                editor.putString("department", department);
//                editor.putString("income", income);
//
                inputAddress.setText(address);
                inputPhoneNumber.setText(phoneNumber);
                inputDesignation.setText(designation);
                inputDepartment.setText(department);
                inputIncome.setText(income);
//                editor.apply();

                Toast.makeText(getApplicationContext(), "Data added.Successfully saved!", Toast.LENGTH_LONG).show();
            } else {
                String newAddress = inputAddress.getText().toString();
                String newPhoneNumber = inputPhoneNumber.getText().toString();
                String newDesignation = inputDesignation.getText().toString();
                String newDepartment = inputDepartment.getText().toString();
                String newIncome = inputIncome.getText().toString();

                userProfile.setAddress(newAddress);
                userProfile.setPhone(newPhoneNumber);
                userProfile.setDesignation(newDesignation);
                userProfile.setDepartment(newDepartment);
                userProfile.setIncome(newIncome);

                dbHelper.updateUserProfileData(lastTableId, newAddress, newPhoneNumber, newDesignation, newDepartment, newIncome);

//
//                editor.putString("address", newAddress);
//                editor.putString("phoneNumber", newPhoneNumber);
//                editor.putString("designation", newDesignation);
//                editor.putString("department", newDepartment);
//                editor.putString("income", newIncome);
//                editor.apply();

                inputAddress.setText(newAddress);
                inputPhoneNumber.setText(newPhoneNumber);
                inputDesignation.setText(newDesignation);
                inputDepartment.setText(newDepartment);
                inputIncome.setText(newIncome);
                Toast.makeText(getApplicationContext(), "Data updated successfully!", Toast.LENGTH_LONG).show();

            }
        } else {
            Toast.makeText(getApplicationContext(), "error", Toast.LENGTH_LONG).show();

        }
        dbHelper.getUserDataCount();
        Log.e("--data count", dbHelper.getUserDataCount() + "");

        List<UserProfile> contacts = dbHelper.getAllUserProfile();

        for (UserProfile cn : contacts) {
            String log = "Id: " + cn.getProfileId() + " ,address: " + cn.getAddress() + " ,income: " + cn.getIncome();
            Log.d("Name: ", log);
            Log.e("--data", "data inserted on click");
        }
    }

    private boolean validateFirstName() {
        firstName = inputFirstName.getText().toString().trim();
        if (firstName.isEmpty()) {
            inputLayoutFirstName.setError(getString(R.string.err_msg_first_name));
            requestFocus(inputFirstName);
            return false;
        } else {
            inputLayoutFirstName.setErrorEnabled(false);
        }
        return true;
    }

    private boolean validateLastName() {
        lastName = inputLastName.getText().toString().trim();

        if (lastName.isEmpty()) {
            inputLayoutLastName.setError(getString(R.string.err_msg_last_name));
            requestFocus(inputLastName);
            return false;
        } else {
            inputLayoutLastName.setErrorEnabled(false);
        }

        return true;
    }

    private boolean validateEmail() {
        email = inputEmail.getText().toString().trim();

        if (email.isEmpty() || !isValidEmail(email)) {
            inputLayoutEmail.setError(getString(R.string.err_msg_email));
            requestFocus(inputEmail);
            return false;
        } else {
            inputLayoutEmail.setErrorEnabled(false);

        }

        return true;
    }

    private boolean validateAddress() {
        address = inputAddress.getText().toString().trim();
        if (address.isEmpty()) {
            inputLayoutAddress.setError(getString(R.string.err_msg_user_address));
            requestFocus(inputAddress);
            return false;
        } else {
            inputLayoutAddress.setErrorEnabled(false);
        }

        return true;
    }

    private boolean validatePhoneNumber() {
        phoneNumber = inputPhoneNumber.getText().toString().trim();
        if (phoneNumber.isEmpty() || !isValidMobile(phoneNumber)) {
            inputLayoutPhoneNumber.setError(getString(R.string.err_msg_user_number));
            requestFocus(inputPhoneNumber);
            return false;
        } else {
            inputLayoutPhoneNumber.setErrorEnabled(false);
        }

        return true;
    }

    private boolean validateDesignation() {
        designation = inputDesignation.getText().toString().trim();
        if (designation.isEmpty()) {
            inputLayoutDesignation.setError(getString(R.string.err_msg_user_designation));
            requestFocus(inputDesignation);
            return false;
        } else {
            inputLayoutDesignation.setErrorEnabled(false);
        }

        return true;
    }

    private boolean validateDepartment() {
        department = inputDepartment.getText().toString().trim();
        if (department.isEmpty()) {
            inputLayoutDepartment.setError(getString(R.string.err_msg_user_department));
            requestFocus(inputDepartment);
            return false;
        } else {
            inputLayoutDepartment.setErrorEnabled(false);
        }

        return true;
    }

    private boolean validateIncome() {
        income = inputIncome.getText().toString().trim();
        if (income.isEmpty()) {
            inputLayoutIncome.setError(getString(R.string.err_msg_user_income));
            requestFocus(inputIncome);
            return false;
        } else {
            inputLayoutIncome.setErrorEnabled(false);
        }

        return true;
    }

    private static boolean isValidEmail(String email) {
        return !TextUtils.isEmpty(email) && android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private boolean isValidMobile(String phone) {
        return android.util.Patterns.PHONE.matcher(phone).matches();
    }

    private void requestFocus(View view) {
        if (view.requestFocus()) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
    }

    private class MyTextWatcher implements TextWatcher {

        private View view;

        private MyTextWatcher(View view) {
            this.view = view;
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void afterTextChanged(Editable editable) {
            switch (view.getId()) {
                case R.id.inputFirstName:
                    validateFirstName();
                    break;
                case R.id.inputLastName:
                    validateLastName();
                    break;
                case R.id.inputEmail:
                    validateEmail();
                    break;
                case R.id.inputAddress:
                    validateAddress();
                    break;
                case R.id.inputPhoneNumber:
                    validatePhoneNumber();
                    break;
                case R.id.inputDesignation:
                    validateDesignation();
                    break;
                case R.id.inputDepartment:
                    validateDepartment();
                    break;
                case R.id.inputIncome:
                    validateIncome();
                    break;
            }
        }
    }
}

